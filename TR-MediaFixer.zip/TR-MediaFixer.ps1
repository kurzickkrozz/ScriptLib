# Load TagLibSharp.dll (place in script directory)
[System.Reflection.Assembly]::LoadFrom((Resolve-Path "TagLibSharp.dll"))
# Get file pattern from user
$filePattern = Read-Host "Enter file pattern (e.g., *.mp4 or C:\videos\*.mp4)"
# Find all matching files recursively
$files = Get-ChildItem -Path $filePattern -File -Recurse
if (-not $files) {
    Write-Host "No files found matching pattern: $filePattern"
    exit
}
# Process each file
foreach ($file in $files) {
    try {
        $video = [TagLib.File]::Create($file.FullName)
        $video.Tag.Title = $file.Name
        $video.Save()
        Write-Host "Updated title for: $($file.FullName)"
    }
    catch {
        Write-Warning "Failed to process $($file.FullName): $_"
    }
}
